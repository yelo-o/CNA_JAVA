package com.mango.exception;

public class RemoveException extends Exception {

	public RemoveException() {
		super();
	}

	public RemoveException(String message) {
		super(message);
	}

}
